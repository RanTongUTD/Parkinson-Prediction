LLM GAMM.R corresponds to the first 2 methods
GNMM corresponds to the 3rd method.
NME code corresponds to  the last method.